﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class abrir_Puerta : MonoBehaviour
{
    [SerializeField]
    GameObject puerta1, puerta2, puerta3;

    float velPuerta = 1f;
    bool esta_Abierta =  false;
   void OnTriggerEnter(Collider col)
    {
        if (col.tag == "llave_Uno")
        {
            if (!esta_Abierta)
            {
                puerta3.transform.position += new Vector3(0, 1, 0) / velPuerta;
            }
        }

        if (col.tag == "llave_Dos")
        {
            if (!esta_Abierta)
            {
                puerta1.transform.position += new Vector3(0, 1, 0) / velPuerta;
            }
        }
        if (col.tag == "llave_Tres")
        {
            if (!esta_Abierta)
            {
                puerta2.transform.position += new Vector3(0, 1, 0) / velPuerta;
            }
        }
    }
}
