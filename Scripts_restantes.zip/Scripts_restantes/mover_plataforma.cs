﻿using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using UnityEngine;

public class mover_plataforma : MonoBehaviour
{

    // Start is called before the first frame update
    public Vector3[] points;
    public int numero_punto = 0;
    private Vector3 distancia_promedio;

    public float tolerancia;
    public float speed;
    public float delay_time;

    private float delat_start;

    public bool automatico;

    void Start()
    {
        if (points.Length > 0)
        {
            distancia_promedio = points[0];
        }
        tolerancia = speed * Time.deltaTime;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position != distancia_promedio)
        {
            Move_Platform();

        }
        else
        {
            actualizar_target();
        }
    }

    void Move_Platform()
    {
        Vector3 heading = distancia_promedio - transform.position;
        transform.position += (heading / heading.magnitude) * speed * Time.deltaTime;
        if (heading.magnitude < tolerancia)
        {
            transform.position = distancia_promedio;
        }

    }
    void actualizar_target()
    {
        if (automatico)
        {
            if (Time.time - delat_start > delay_time)
            {
                Siguiente_platform();
            }
        }
    }

    void Siguiente_platform()
    {
        numero_punto++;
        if (numero_punto >= points.Length)
        {
            numero_punto = 0;
        }
        distancia_promedio = points[numero_punto];
    }

    private void OnTriggerEnter(Collider obj)
    {
        obj.transform.parent = transform;
    }

    private void OnTriggerExit(Collider obj)
    {
        obj.transform.parent = null;
    }
}
