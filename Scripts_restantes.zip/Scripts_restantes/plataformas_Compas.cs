﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class plataformas_Compas : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    GameObject plataforma_3, plat_3Dos;
    float speed_platform = 0.9f;
    bool esta_Abierta = false;

    void OnTriggerEnter(Collider obj)
    {
       
        if (obj.tag == "Player")
        {
            if (!esta_Abierta)
            {
                plataforma_3.transform.position += new Vector3(0, 1, 0) / speed_platform;
                plat_3Dos.transform.position += new Vector3(0, 1, 0) / speed_platform;
            }

        }
    }
}
