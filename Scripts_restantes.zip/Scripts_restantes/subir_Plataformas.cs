﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class subir_Plataformas : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    GameObject platform_1, platform_2, platform_3;
    float speed_platform = 0.9f;
    bool esta_Abierta = false;

    void OnTriggerEnter(Collider obj)
    {
        if (obj.tag == "helice_Uno")
        {
            if (!esta_Abierta)
            {
                platform_1.transform.position += new Vector3(0, 1, 0) / speed_platform;
            }
        }
        if (obj.tag == "helice_Dos")
        {
            if (!esta_Abierta)
            {
                platform_2.transform.position += new Vector3(0, 1, 0) / speed_platform;
            }
        }

        if (obj.tag == "Player")
        {
            if (!esta_Abierta)
            {
                platform_3.transform.position += new Vector3(0, 1, 0) / speed_platform;
            }
          
        }
    }
}
