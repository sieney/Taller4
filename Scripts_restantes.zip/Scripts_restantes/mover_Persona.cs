﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mover_Persona : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed;
    public Rigidbody objeto;
    void Start()
    {
        objeto = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        objeto.velocity = new Vector3(Input.GetAxis("Horizontal") * speed, objeto.velocity.y, Input.GetAxis("Vertical") * speed);
    }
}
